"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Patients = (function () {
    function Patients() {
    }
    return Patients;
}());
exports.Patients = Patients;
//# sourceMappingURL=Patient.js.map