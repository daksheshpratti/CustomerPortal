export class Patients {
     accountBalance: String

address:String

age: Number

alcohol:String

countryOfOrigin:String

dob:String

drugAddict:String

email:String

firstName:String

gender:String

height:String

id: Number

lastName:String

membershipType:String

mentalIllness:String

mobile:String

password:String

smoking:String

username:String

weight:String

}